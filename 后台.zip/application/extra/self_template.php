<?php

return array (
  'modules' => 
  array (
    'index' => 
    array (
      'name' => 'newkale',
      'title' => '新版模板',
      'intro' => '新版模板',
      'author' => '源分享珈蓝',
      'site' => '',
      'version' => '1.0.0',
      'state' => '1',
      'thumb' => '/uploads/20220214/513a016409460535e12e91dab6ef9e7d.png',
      'view_base' => '../public/templates/modules/newkale/',
    ),
  ),
);
