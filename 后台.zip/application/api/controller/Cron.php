<?php

namespace app\api\controller;
use think\Db;
use app\common\controller\Api;
use app\common\library\Email;
use app\common\model\User;
use think\Config;
use app\api\library\Alipay;
use fast\Http;
use think\Exception;
@set_time_limit(0);
/**
 * 首页接口
 */
class Cron extends Api
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];
    
    
    public function index()
    {
        $this->success('此版本无需此计划任务');
    }
     
    public function alipay()
    {
        $this->success('此版本无需此计划任务');
    }
    public function alipay_gr()
    {
        $this->success('此版本无需此计划任务');
    }
    
}
