<?php

namespace app\api\controller;
use think\Db;
use app\common\controller\Api;
use app\common\library\Email;
use think\Config;
use app\api\library\Alipay;
use fast\Http;
use think\Exception;
@set_time_limit(0);
/**
 * 首页接口
 */
class Front extends Api
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];
    
    //内部调用获取QQ订单 
    public function GetOrder($channelid='',$userid='')
    {
        $qrlist = Db::name('qrlist')->where('id',$channelid)->where('user_id',$userid)->find();
        if($qrlist['type']!="qqpay")
        {
            $this->error("请求错误");
        }
        if(empty($qrlist))
        {
            $this->error("通道不存在");
        }
        $aliobj = new Alipay();
        $cookie = base64_decode($qrlist['cookie']);
        if(strlen($cookie)<50)
        {
            try {
              $this->sendsms($userid,"QQ");
            } catch (Exception $e) {
                
            }
            Db::name('qrlist')->where('id',$channelid)->update(['status' => 0]);
            $this->error("通道已掉线");
        }
        $odlist = $aliobj->GetOrder($qrlist['qq'],$cookie);//获取订单
        $arr = json_decode($odlist, true);
        if(empty($arr))
        {
            //********执行掉线通知***********
            try {
              $this->sendsms($userid,"QQ");
            } catch (Exception $e) {
                
            }
            
            Db::name('qrlist')->where('id', $channelid)->update(['status' => 0]);
            $this->error("通道已掉线");
        }
        if($arr['retcode'] != 0 && $arr['retmsg'] != 'OK')
        {
            //********执行掉线通知***********
            try {
              $this->sendsms($userid,"QQ");
            } catch (Exception $e) {
                
            }
            Db::name('qrlist')->where('id',$channelid)->update(['status' => 0]);
            $this->error("通道已掉线");
        }
        if(!empty($arr['records'][0]))
        {
            $param = $arr['records'][0];
            $money = $param['price'] / 100;
            $sp_billno = $param['sp_billno'];
            if($sp_billno!=$qrlist['cloud_server_name'])
            {
                $res['qq_orderno'] = $sp_billno;
                $res['money'] = $money;
                //$res['qq_memo'] = $qqmemo;
                Db::name('qrlist')->where('id', $channelid)->update(['cloud_server_name' => $sp_billno]);
                $this->success('获取成功',$res);
            }
            else
            {
                $this->error("未查询到新的订单记录");
            }
        }
        else
        {
            $this->error("未查询到订单记录");
        }
    }
    
    //内部调用保活并获取支付宝余额
    public function GetAliPayMoney($channelid='',$userid='')
    {
        $qrlist = Db::name('qrlist')->where('id',$channelid)->where('user_id',$userid)->find();
        if(empty($qrlist))
        {
            $this->error("通道不存在");
        }
        if($qrlist['type']!="alipay")
        {
            $this->error("请求错误");
        }
        if(strlen($qrlist['cookie'])<50)
        {
            try {
              $this->sendsms($userid,"支付宝");
            } catch (Exception $e) {
                
            }
            Db::name('qrlist')->where('id',$channelid)->update(['status' => 0]);
            $this->error("通道已掉线");
        }
        $cookie = base64_decode($qrlist['cookie']);
        
        $aliobj = new Alipay();
        $bh = $aliobj->BaoHuo($cookie);
        $m = $aliobj->GetMyMoney_2($cookie);
        //return json($m);
        if($m['status']==true)
        {
            if($qrlist['money']!=$m['money'])
            {
                $money =sprintf("%.2f",$qrlist['money']);
                $res['money'] = $m['money'];
                $res['ordermoney'] = $money;
                Db::name('qrlist')->where('id', $channelid)->update(['money' => $res['money']]);
                $this->success('获取成功',$res);
            }
            else
            {
                $this->error("轮训1无变化不做处理");
            }
        }
        else
        {
            $m = $aliobj->Get_pay_money($cookie);
            if($m['status']==true)
            {
                $availableAmount = $m['money'];
                if($qrlist['money']!=$availableAmount)
                {
                    $money =sprintf("%.2f",$qrlist['money']);
                    $res['money'] = $availableAmount;
                    $res['ordermoney'] = $money;
                    Db::name('qrlist')->where('id', $channelid)->update(['money' => $res['money']]);
                    $this->success('获取成功',$res);
                }
                else
                {
                    $this->error("轮训2无变化不做处理");
                }
                
            }
            else
            {
                $m = $aliobj->GetMyMoney_2($cookie);
                if($m['status']==true)
                {
                    $availableAmount = $m['money'];
                    if($qrlist['money']!=$availableAmount)
                    {
                        $money =sprintf("%.2f",$qrlist['money']);
                        $res['money'] = $availableAmount;
                        $res['ordermoney'] = $money;
                        Db::name('qrlist')->where('id', $channelid)->update(['money' => $res['money']]);
                        $this->success('获取成功',$res);
                    }
                    else
                    {
                        $this->error("轮训3无变化不做处理");
                    }
                }
                else
                {
                    try {
                      $this->sendsms($userid,"支付宝");
                    } catch (Exception $e) {
                        
                    }
                    Db::name('qrlist')->where('id',$channelid)->update(['status' => 0]);
                }
            }
        }
    }
    
    //内部调用获取支付宝订单详情
    public function GetOrderList($channelid='',$userid='')
    {
        $qrlist = Db::name('qrlist')->where('id',$channelid)->where('user_id',$userid)->find();
        if(empty($qrlist))
        {
            $this->error("通道不存在");
        }
        $cookie = base64_decode($qrlist['cookie']);
        $aliobj = new Alipay();
        $order_count = Db::name('order')->where('qr_id',$channelid)->where('status',0)->where('out_time','>',time())->count();
        if($order_count>0)
        {
            $orders = $aliobj->getAliOrder($cookie,$qrlist['zfb_pid']);
            if($orders['status']==='deny')
            {
                //********************掉线发送邮件***********************
                $this->sendsms($userid,"支付宝");
                Db::name('qrlist')->where('id',$channelid)->update(['status' => 0]);
                $this->error("通道掉线");
            }
            $_orderlist=empty($orders['result']['detail'])?array():$orders['result']['detail'];
            if(!empty($_orderlist))
            {
                $res['aliorder'] = $_orderlist;
                $this->success('获取成功',$res);
            }
            else
            {
                $this->error("获取失败");
            }
        }
        else
        {
            $this->error("无订单");
        }
    }
    
    function sendsms($receiver='',$name='')
    {
        $config = Config::get('site');
        $user = Db::name('user')->where('id',$receiver)->find();
        $obj = \app\common\library\Email::instance();
        $result = $obj
                ->to($user['email'])
                ->subject(__("掉线通知邮件-", config('site.name')))
                ->message('<div style="min-height:550px; padding: 100px 55px 200px;">' . __('您有'.$name.'通道已掉线，请登录检查', config('site.name')) . '</div>')
                ->send();
        return true; 
    }
    
    
    

}
