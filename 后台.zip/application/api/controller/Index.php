<?php

namespace app\api\controller;
use think\Db;
use app\common\controller\Api;
use app\api\library\AlipayTools;
/**
 * 首页接口
 */
class Index extends Api
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];

    /**
     * 首页
     *
     */
    public function index()
    {
        $this->success("YPAY");
    }
    

    
    
    
}
