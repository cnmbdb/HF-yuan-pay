<?php

namespace app\api\controller;
use think\Db;
use app\common\controller\Api;
use think\Config;
use app\common\model\User;
use app\common\library\Jialan;
use fast\Http;
use think\Exception;
/**
 * 微信店员监控接口
 */
class Wechat extends Api
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];
    
    /**
     * 软件通讯密钥验证
     */
    public function auth($apikey='')
    {
        $config = Config::get('site');
        if(empty($apikey))
        {
            $this->error("通讯密钥不可为空");
        }
        if(empty($config['cloud_key']))
        {
            $this->error("还未设置通讯密钥");
        }
        if($apikey==$config['cloud_key'])
        {
            $this->success('验证通过');
        }
        else
        {
            $this->error("通讯密钥错误!");
        }
    }

    /**
     * 微信收款通知
     */
    public function notity($apikey='',$money='',$wxname='')
    {
        $config = Config::get('site');
        if(empty($apikey))
        {
            $this->success("通讯密钥不可为空");
        }
        if(empty($config['cloud_key']))
        {
            $this->success("还未设置通讯密钥");
        }
        if($apikey!=$config['cloud_key'])
        {
            $this->success('密钥错误,请检查');
        }
        if(empty($money))
        {
            $this->success('金额参数不可为空');
        }
        if(empty($wxname))
        {
            $this->success('店员名称参数不可为空');
        }
        //查询此店员名称,如果不在线则修改状态为在线
        $qrmodel = Db::name('qrlist')->where('wx_name', $wxname)->find();
        if($qrmodel['status']==0)
        {
            Db::name('qrlist')->where('wx_name', $wxname)->update(['status' => 1]);
        }
        $orderrow = Db::name('order')->where('qr_id',$qrmodel['id'])->where('status',0)->where('typedata','wxpay')->where('truemoney',$money)->where('out_time','>',time())->order('id desc')->find();
        if(empty($orderrow))
        {
            $this->success('店员名称：'.$wxname.' 金额：'.$money.' 未查询到平台有订单');
        }
        //检测完毕
        $u = Jialan::creat_callback($orderrow);
        get_curl($u['notify']);
        $this->success('请求成功');
    }
    
    
    
    
}
