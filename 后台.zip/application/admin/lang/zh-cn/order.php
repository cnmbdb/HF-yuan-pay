<?php

return [
    'Id'              => 'ID',
    'Trade_no'        => '本地单号',
    'Out_trade_no'    => '商户单号',
    'Notify_url'      => '异步通知地址',
    'Return_url'      => '同步通知地址',
    'Typedata'        => '支付类型',
    'Typedata alipay' => '支付宝',
    'Typedata wxpay'  => '微信',
    'Typedata qqpay'  => '钱包',
    'User_id'         => '商户ID',
    'Name'            => '商品名称',
    'Money'           => '金额',
    'Truemoney'       => '实付金额',
    'Qr_id'           => '通道ID',
    'Ip'              => '访问IP',
    'Createtime'      => '创建时间',
    'End_time'        => '支付时间',
    'Out_time'        => '有效时限',
    'Status'          => '状态',
    'Status 0'        => '未支付',
    'Status 1'        => '已支付',
    'Qrcode'          => '二维码信息'
];
