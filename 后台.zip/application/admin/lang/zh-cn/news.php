<?php

return [
    'Id'         => 'ID',
    'Type'       => '类型',
    'Weigh'      => '排序',
    'Name'       => '标题',
    'Content'    => '内容',
    'Creat_time' => '发布时间'
];
