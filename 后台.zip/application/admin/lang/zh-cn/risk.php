<?php

return [
    'Id'          => 'ID',
    'User_id'     => '商户ID',
    'Urltext'     => '来源地址',
    'Contenttext' => '风控内容',
    'Createtime'  => '创建时间'
];
