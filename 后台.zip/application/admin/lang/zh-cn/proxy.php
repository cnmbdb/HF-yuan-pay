<?php

return [
    'Id'         => 'ID',
    'Name'       => '名称',
    'Address'    => 'IP地址',
    'Prot'       => '端口',
    'User'       => '用户名',
    'Pass'       => '密码',
    'Status'     => '状态',
    'Creat_time' => '创建时间'
];
