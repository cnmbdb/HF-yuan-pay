<?php

return [
    'Id'              => 'ID',
    'User_id'         => '商户ID',
    'Type'            => '通道类型',
    'Type alipay'     => '支付宝',
    'Type wxpay'      => '微信',
    'Type qqpay'      => '钱包',
    'Qr_url'          => '二维码地址',
    'Memo'            => '备注',
    'Wx_name'         => '微信昵称',
    'Money'           => '已收款金额',
    'Succ_ordercount' => '已收款数',
    'Cookie'          => '登录Cookie',
    'Createtime'      => '创建时间',
    'Updatetime'      => '监控时间',
    'End_time'        => '失效时间',
    'Zfb_pid'         => '支付宝PID',
    'Moshi'           => '模式1.CK 2.其他监控',
    'Status'          => '状态',
    'Diaoxian_notity' => '掉线通知状态'
];
