<?php

return [
    'Id'         => '主键ID',
    'Orderid'    => '订单ID',
    'User_id'    => '会员ID',
    'Amount'     => '订单金额',
    'Payamount'  => '支付金额',
    'Paytype'    => '支付类型',
    'Paytime'    => '支付时间',
    'Ip'         => 'IP地址',
    'Useragent'  => 'UserAgent',
    'Memo'       => '备注',
    'Createtime' => '添加时间',
    'Updatetime' => '更新时间',
    'Status'     => '状态'
];
