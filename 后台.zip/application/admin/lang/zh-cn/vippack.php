<?php

return [
    'Id'              => 'ID',
    'Vip_nametext'    => '套餐名称',
    'Vip_type'        => '套餐类型',
    'Vip_type alipay' => '支付宝',
    'Vip_type wxpay'  => '微信',
    'Vip_type qqpay'  => '钱包',
    'Taocans'         => '套餐配置',
    'Vip_feilvtext'   => '套餐费率',
    'Create_time'     => '添加时间',
    'Status'          => '状态',
    'Status 0'        => '关闭',
    'Status 1'        => '启用',
    'Weigh'           => '排序'
];
