<?php

return [
    'Id'          => 'ID',
    'Wx_name'     => '微信名称',
    'Wx_user'     => '微信账号',
    'Update_time' => '刷新时间',
    'Creat_time'  => '创建时间',
    'Status'      => '状态',
    'Status 0'    => '离线',
    'Status 1'    => '在线'
];
