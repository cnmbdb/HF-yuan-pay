<?php

return [
    'User_id'    => '商户ID',
    'Code'       => '通道标识',
    'Qrlist_id'  => '账号ID',
    'Ewm_url'    => '二维码地址',
    'Money'      => '金额',
    'Creat_time' => '创建时间',
    'End_time'   => '有效时间'
];
