<?php

return [
    'Id'         => 'ID',
    'Name'       => '通道名称',
    'Type'       => '通道类型',
    'Weigh'      => '排序',
    'Remark'     => '备注',
    'Is_hot'     => '热门',
    'Creat_time' => '创建时间',
    'Status'     => '状态'
];
