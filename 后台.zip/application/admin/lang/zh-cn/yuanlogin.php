<?php

return [
    'Id'    => 'ID',
    'Name'  => '通道名称',
    'Url'   => '通道地址',
    'Value' => '通道数据',
    'Type'  => '通道类型',
    'Weigh' => '排序'
];
