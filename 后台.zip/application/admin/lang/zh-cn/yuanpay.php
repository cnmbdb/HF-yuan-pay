<?php

return [
    'Status' => '是否启用'
];
