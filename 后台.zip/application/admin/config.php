<?php

//配置文件
return [
    'url_common_param'       => true,
    'url_html_suffix'        => '',
    'controller_auto_search' => true,
    'app_version_name'       => 'YuanPay',
    'app_version_code'       => '300',
];
