-- phpMyAdmin SQL Dump
-- version 4.0.10.20
-- https://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2022-04-05 13:03:00
-- 服务器版本: 5.6.50-log
-- PHP 版本: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `v5sql`
--

-- --------------------------------------------------------

--
-- 表的结构 `fa_admin`
--

CREATE TABLE IF NOT EXISTS `fa_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `username` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '用户名',
  `nickname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '昵称',
  `password` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '密码',
  `salt` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '密码盐',
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '头像',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '电子邮箱',
  `loginfailure` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '失败次数',
  `logintime` int(10) DEFAULT NULL COMMENT '登录时间',
  `loginip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '登录IP',
  `createtime` int(10) DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) DEFAULT NULL COMMENT '更新时间',
  `token` varchar(59) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'Session标识',
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `cloudkey` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cloud_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='管理员表' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `fa_admin`
--

INSERT INTO `fa_admin` (`id`, `username`, `nickname`, `password`, `salt`, `avatar`, `email`, `loginfailure`, `logintime`, `loginip`, `createtime`, `updatetime`, `token`, `status`, `cloudkey`, `cloud_url`) VALUES
(1, 'admin', '后台管理员', 'bb35872469c81515c5d5cfb0517d8f30', '91ee16', '/uploads/20220120/0daf6e33b0b11684a112c3a9e85c269b.png', 'admin@admin.com', 0, 1648979736, '112.37.203.47', 1491635035, 1648979736, '8a05d32d-ba34-435b-8446-4ec35173ade7', 'normal', '', '/');

-- --------------------------------------------------------

--
-- 表的结构 `fa_admin_log`
--

CREATE TABLE IF NOT EXISTS `fa_admin_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员ID',
  `username` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '管理员名字',
  `url` varchar(1500) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '操作页面',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '日志标题',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '内容',
  `ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'IP',
  `useragent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'User-Agent',
  `createtime` int(10) DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`),
  KEY `name` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='管理员日志表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_area`
--

CREATE TABLE IF NOT EXISTS `fa_area` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(10) DEFAULT NULL COMMENT '父id',
  `shortname` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '简称',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `mergename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '全称',
  `level` tinyint(4) DEFAULT NULL COMMENT '层级 0 1 2 省市区县',
  `pinyin` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '拼音',
  `code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '长途区号',
  `zip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮编',
  `first` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '首字母',
  `lng` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '经度',
  `lat` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '纬度',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='地区表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_attachment`
--

CREATE TABLE IF NOT EXISTS `fa_attachment` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `category` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '类别',
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员ID',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '物理路径',
  `imagewidth` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '宽度',
  `imageheight` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '高度',
  `imagetype` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '图片类型',
  `imageframes` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '图片帧数',
  `filename` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '文件名称',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `mimetype` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'mime类型',
  `extparam` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '透传数据',
  `createtime` int(10) DEFAULT NULL COMMENT '创建日期',
  `updatetime` int(10) DEFAULT NULL COMMENT '更新时间',
  `uploadtime` int(10) DEFAULT NULL COMMENT '上传时间',
  `storage` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'local' COMMENT '存储位置',
  `sha1` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '文件 sha1编码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='附件表' AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_auth_group`
--

CREATE TABLE IF NOT EXISTS `fa_auth_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父组别',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '组名',
  `rules` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '规则ID',
  `createtime` int(10) DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) DEFAULT NULL COMMENT '更新时间',
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='分组表' AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `fa_auth_group`
--

INSERT INTO `fa_auth_group` (`id`, `pid`, `name`, `rules`, `createtime`, `updatetime`, `status`) VALUES
(1, 0, 'Admin group', '*', 1491635035, 1491635035, 'normal'),
(2, 1, 'Second group', '13,14,16,15,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,40,41,42,43,44,45,46,47,48,49,50,55,56,57,58,59,60,61,62,63,64,65,1,9,10,11,7,6,8,2,4,5', 1491635035, 1491635035, 'normal'),
(3, 2, 'Third group', '1,4,9,10,11,13,14,15,16,17,40,41,42,43,44,45,46,47,48,49,50,55,56,57,58,59,60,61,62,63,64,65,5', 1491635035, 1491635035, 'normal'),
(4, 1, 'Second group 2', '1,4,13,14,15,16,17,55,56,57,58,59,60,61,62,63,64,65', 1491635035, 1491635035, 'normal'),
(5, 2, 'Third group 2', '1,2,6,7,8,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34', 1491635035, 1491635035, 'normal');

-- --------------------------------------------------------

--
-- 表的结构 `fa_auth_group_access`
--

CREATE TABLE IF NOT EXISTS `fa_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '会员ID',
  `group_id` int(10) unsigned NOT NULL COMMENT '级别ID',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='权限分组表';

--
-- 转存表中的数据 `fa_auth_group_access`
--

INSERT INTO `fa_auth_group_access` (`uid`, `group_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- 表的结构 `fa_auth_rule`
--

CREATE TABLE IF NOT EXISTS `fa_auth_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('menu','file') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'file' COMMENT 'menu为菜单,file为权限节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '规则名称',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '规则名称',
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '图标',
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '规则URL',
  `condition` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '条件',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '备注',
  `ismenu` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为菜单',
  `menutype` enum('addtabs','blank','dialog','ajax') COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '菜单类型',
  `extend` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '扩展属性',
  `py` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '拼音首字母',
  `pinyin` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '拼音',
  `createtime` int(10) DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) DEFAULT NULL COMMENT '更新时间',
  `weigh` int(10) NOT NULL DEFAULT '0' COMMENT '权重',
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`) USING BTREE,
  KEY `pid` (`pid`),
  KEY `weigh` (`weigh`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点表' AUTO_INCREMENT=257 ;

--
-- 转存表中的数据 `fa_auth_rule`
--

INSERT INTO `fa_auth_rule` (`id`, `type`, `pid`, `name`, `title`, `icon`, `url`, `condition`, `remark`, `ismenu`, `menutype`, `extend`, `py`, `pinyin`, `createtime`, `updatetime`, `weigh`, `status`) VALUES
(1, 'file', 0, 'dashboard', '后台首页', 'fa fa-dashboard', '', '', 'Dashboard tips', 1, 'addtabs', '', 'htsy', 'houtaishouye', 1491635035, 1635051774, 143, 'normal'),
(2, 'file', 0, 'general', '常规管理', 'fa fa-cogs', '', '', '', 1, 'addtabs', '', 'cggl', 'changguiguanli', 1491635035, 1642967269, 137, 'normal'),
(4, 'file', 2, 'addon', '插件管理', 'fa fa-rocket', '', '', 'Addon tips', 1, 'addtabs', '', 'cjgl', 'chajianguanli', 1491635035, 1648980148, 0, 'hidden'),
(5, 'file', 0, 'auth', '权限管理', 'fa fa-group', '', '', '', 1, 'addtabs', '', 'qxgl', 'quanxianguanli', 1491635035, 1642967281, 99, 'normal'),
(6, 'file', 2, 'general/config', 'Config', 'fa fa-cog', '', '', 'Config tips', 1, NULL, '', 'xtpz', 'xitongpeizhi', 1491635035, 1491635035, 60, 'normal'),
(7, 'file', 2, 'general/attachment', '附件管理', 'fa fa-file-image-o', '', '', 'Attachment tips', 1, 'addtabs', '', 'fjgl', 'fujianguanli', 1491635035, 1648875034, 53, 'hidden'),
(8, 'file', 2, 'general/profile', 'Profile', 'fa fa-user', '', '', '', 1, NULL, '', 'grzl', 'gerenziliao', 1491635035, 1491635035, 34, 'normal'),
(9, 'file', 5, 'auth/admin', 'Admin', 'fa fa-user', '', '', 'Admin tips', 1, NULL, '', 'glygl', 'guanliyuanguanli', 1491635035, 1491635035, 118, 'normal'),
(11, 'file', 5, 'auth/group', 'Group', 'fa fa-group', '', '', 'Group tips', 1, NULL, '', 'jsz', 'juesezu', 1491635035, 1491635035, 109, 'normal'),
(12, 'file', 5, 'auth/rule', 'Rule', 'fa fa-bars', '', '', 'Rule tips', 1, NULL, '', 'cdgz', 'caidanguize', 1491635035, 1491635035, 104, 'normal'),
(13, 'file', 1, 'dashboard/index', 'View', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1491635035, 1645194178, 136, 'normal'),
(14, 'file', 1, 'dashboard/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1491635035, 1645194178, 135, 'normal'),
(15, 'file', 1, 'dashboard/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1491635035, 1645194178, 133, 'normal'),
(16, 'file', 1, 'dashboard/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1491635035, 1645194178, 134, 'normal'),
(17, 'file', 1, 'dashboard/multi', 'Multi', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1491635035, 1645194178, 132, 'normal'),
(18, 'file', 6, 'general/config/index', 'View', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1491635035, 1645194178, 52, 'normal'),
(19, 'file', 6, 'general/config/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1491635035, 1645194178, 51, 'normal'),
(20, 'file', 6, 'general/config/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1491635035, 1645194178, 50, 'normal'),
(21, 'file', 6, 'general/config/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1491635035, 1645194178, 49, 'normal'),
(22, 'file', 6, 'general/config/multi', 'Multi', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1491635035, 1645194178, 48, 'normal'),
(23, 'file', 7, 'general/attachment/index', 'View', 'fa fa-circle-o', '', '', 'Attachment tips', 0, NULL, '', 'zk', 'zhakan', 1491635035, 1645194178, 59, 'normal'),
(24, 'file', 7, 'general/attachment/select', 'Select attachment', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'xzfj', 'xuanzefujian', 1491635035, 1645194178, 58, 'normal'),
(25, 'file', 7, 'general/attachment/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1491635035, 1645194178, 57, 'normal'),
(26, 'file', 7, 'general/attachment/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1491635035, 1645194178, 56, 'normal'),
(27, 'file', 7, 'general/attachment/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1491635035, 1645194178, 55, 'normal'),
(28, 'file', 7, 'general/attachment/multi', 'Multi', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1491635035, 1645194178, 54, 'normal'),
(29, 'file', 8, 'general/profile/index', 'View', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1491635035, 1645194178, 33, 'normal'),
(30, 'file', 8, 'general/profile/update', 'Update profile', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'gxgrxx', 'gengxingerenxinxi', 1491635035, 1645194178, 32, 'normal'),
(31, 'file', 8, 'general/profile/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1491635035, 1645194178, 31, 'normal'),
(32, 'file', 8, 'general/profile/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1491635035, 1645194178, 30, 'normal'),
(33, 'file', 8, 'general/profile/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1491635035, 1645194178, 29, 'normal'),
(34, 'file', 8, 'general/profile/multi', 'Multi', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1491635035, 1645194178, 28, 'normal'),
(40, 'file', 9, 'auth/admin/index', 'View', 'fa fa-circle-o', '', '', 'Admin tips', 0, NULL, '', 'zk', 'zhakan', 1491635035, 1645194178, 117, 'normal'),
(41, 'file', 9, 'auth/admin/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1491635035, 1645194178, 116, 'normal'),
(42, 'file', 9, 'auth/admin/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1491635035, 1645194178, 115, 'normal'),
(43, 'file', 9, 'auth/admin/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1491635035, 1645194178, 114, 'normal'),
(47, 'file', 11, 'auth/group/index', 'View', 'fa fa-circle-o', '', '', 'Group tips', 0, NULL, '', 'zk', 'zhakan', 1491635035, 1645194178, 108, 'normal'),
(48, 'file', 11, 'auth/group/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1491635035, 1645194178, 107, 'normal'),
(49, 'file', 11, 'auth/group/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1491635035, 1645194178, 106, 'normal'),
(50, 'file', 11, 'auth/group/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1491635035, 1645194178, 105, 'normal'),
(51, 'file', 12, 'auth/rule/index', 'View', 'fa fa-circle-o', '', '', 'Rule tips', 0, NULL, '', 'zk', 'zhakan', 1491635035, 1645194178, 103, 'normal'),
(52, 'file', 12, 'auth/rule/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1491635035, 1645194178, 102, 'normal'),
(53, 'file', 12, 'auth/rule/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1491635035, 1645194178, 101, 'normal'),
(54, 'file', 12, 'auth/rule/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1491635035, 1645194178, 100, 'normal'),
(55, 'file', 4, 'addon/index', 'View', 'fa fa-circle-o', '', '', 'Addon tips', 0, NULL, '', 'zk', 'zhakan', 1491635035, 1645194178, 0, 'normal'),
(56, 'file', 4, 'addon/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1491635035, 1645194178, 0, 'normal'),
(57, 'file', 4, 'addon/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1491635035, 1645194178, 0, 'normal'),
(58, 'file', 4, 'addon/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1491635035, 1645194178, 0, 'normal'),
(59, 'file', 4, 'addon/downloaded', 'Local addon', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bdcj', 'bendichajian', 1491635035, 1645194178, 0, 'normal'),
(60, 'file', 4, 'addon/state', 'Update state', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'jyqy', 'jinyongqiyong', 1491635035, 1645194178, 0, 'normal'),
(63, 'file', 4, 'addon/config', 'Setting', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'pz', 'peizhi', 1491635035, 1645194178, 0, 'normal'),
(64, 'file', 4, 'addon/refresh', 'Refresh', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sx', 'shuaxin', 1491635035, 1645194178, 0, 'normal'),
(65, 'file', 4, 'addon/multi', 'Multi', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1491635035, 1645194178, 0, 'normal'),
(66, 'file', 0, 'user', '商户管理', 'fa fa-user-circle', '', '', '', 1, 'addtabs', '', 'shgl', 'shanghuguanli', 1491635035, 1642967289, 0, 'normal'),
(67, 'file', 66, 'user/user', '会员管理', 'fa fa-user', '', '', '', 1, 'addtabs', '', 'hygl', 'huiyuanguanli', 1491635035, 1634054955, 0, 'normal'),
(68, 'file', 67, 'user/user/index', 'View', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1491635035, 1645194178, 0, 'normal'),
(69, 'file', 67, 'user/user/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1491635035, 1645194178, 0, 'normal'),
(70, 'file', 67, 'user/user/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1491635035, 1645194178, 0, 'normal'),
(71, 'file', 67, 'user/user/del', 'Del', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1491635035, 1645194178, 0, 'normal'),
(72, 'file', 67, 'user/user/multi', 'Multi', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1491635035, 1645194178, 0, 'normal'),
(112, 'file', 66, 'vippack', '会员套餐', 'fa fa-vimeo-square', '', '', '', 1, 'addtabs', '', 'hytc', 'huiyuantaocan', 1630901413, 1630901658, 0, 'normal'),
(113, 'file', 112, 'vippack/import', 'Import', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'dr', 'daoru', 1630901413, 1633457546, 0, 'normal'),
(114, 'file', 112, 'vippack/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1630901413, 1633457546, 0, 'normal'),
(115, 'file', 112, 'vippack/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1630901413, 1633457546, 0, 'normal'),
(116, 'file', 112, 'vippack/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1630901413, 1633457546, 0, 'normal'),
(117, 'file', 112, 'vippack/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1630901413, 1633457546, 0, 'normal'),
(118, 'file', 112, 'vippack/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1630901413, 1633457546, 0, 'normal'),
(125, 'file', 199, 'risk', '风控记录', 'fa fa-map', '', '', '', 1, 'addtabs', '', 'fkjl', 'fengkongjilu', 1630913325, 1636510350, 0, 'normal'),
(126, 'file', 125, 'risk/import', 'Import', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'dr', 'daoru', 1630913325, 1630913325, 0, 'normal'),
(127, 'file', 125, 'risk/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1630913325, 1630913325, 0, 'normal'),
(128, 'file', 125, 'risk/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1630913325, 1630913325, 0, 'normal'),
(129, 'file', 125, 'risk/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1630913325, 1630913325, 0, 'normal'),
(130, 'file', 125, 'risk/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1630913325, 1630913325, 0, 'normal'),
(131, 'file', 125, 'risk/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1630913325, 1630913325, 0, 'normal'),
(132, 'file', 200, 'order', '订单记录', 'fa fa-chrome', '', '', '', 1, 'addtabs', '', 'ddjl', 'dingdanjilu', 1630913325, 1636510420, 0, 'normal'),
(133, 'file', 132, 'order/import', 'Import', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'dr', 'daoru', 1630913325, 1633458803, 0, 'normal'),
(134, 'file', 132, 'order/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1630913325, 1633458803, 0, 'normal'),
(135, 'file', 132, 'order/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1630913325, 1633458803, 0, 'normal'),
(136, 'file', 132, 'order/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1630913325, 1633458803, 0, 'normal'),
(137, 'file', 132, 'order/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1630913325, 1633458803, 0, 'normal'),
(138, 'file', 132, 'order/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1630913325, 1633458803, 0, 'normal'),
(139, 'file', 197, 'qrlist', '账号管理', 'fa fa-xing-square', '', '', '', 1, 'addtabs', '', 'zhgl', 'zhanghaoguanli', 1630929963, 1636510027, 0, 'normal'),
(140, 'file', 139, 'qrlist/import', 'Import', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'dr', 'daoru', 1630929963, 1645197523, 0, 'normal'),
(141, 'file', 139, 'qrlist/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1630929963, 1645197531, 0, 'normal'),
(142, 'file', 139, 'qrlist/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1630929963, 1645197524, 0, 'normal'),
(143, 'file', 139, 'qrlist/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1630929963, 1645197527, 0, 'normal'),
(144, 'file', 139, 'qrlist/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1630929963, 1633459371, 0, 'normal'),
(145, 'file', 139, 'qrlist/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1630929963, 1645197528, 0, 'normal'),
(152, 'file', 197, 'wxemp', '店员列表', 'fa fa-wechat', '', '', '', 1, 'addtabs', '', 'dylb', 'dianyuanliebiao', 1632033584, 1648202007, 0, 'hidden'),
(153, 'file', 152, 'wxemp/import', 'Import', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'dr', 'daoru', 1632033584, 1632033584, 0, 'normal'),
(154, 'file', 152, 'wxemp/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1632033584, 1632033584, 0, 'normal'),
(155, 'file', 152, 'wxemp/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1632033584, 1632033584, 0, 'normal'),
(156, 'file', 152, 'wxemp/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1632033584, 1632033584, 0, 'normal'),
(157, 'file', 152, 'wxemp/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1632033584, 1632033584, 0, 'normal'),
(158, 'file', 152, 'wxemp/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1632033584, 1632033584, 0, 'normal'),
(159, 'file', 200, 'recharge_order', '充值管理', 'fa fa-yen', '', '', '', 1, 'addtabs', '', 'czgl', 'chongzhiguanli', 1632113616, 1636510432, 0, 'normal'),
(160, 'file', 159, 'recharge_order/import', 'Import', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'dr', 'daoru', 1632113616, 1632113616, 0, 'normal'),
(161, 'file', 159, 'recharge_order/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1632113616, 1632113616, 0, 'normal'),
(162, 'file', 159, 'recharge_order/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1632113616, 1632113616, 0, 'normal'),
(163, 'file', 159, 'recharge_order/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1632113616, 1632113616, 0, 'normal'),
(164, 'file', 159, 'recharge_order/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1632113616, 1632113616, 0, 'normal'),
(165, 'file', 159, 'recharge_order/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1632113616, 1632113616, 0, 'normal'),
(169, 'file', 2, 'yuanpay', '支付配置', 'fa fa-firefox', '', '', '', 1, 'addtabs', '', 'zfpz', 'zhifupeizhi', 1636171906, 1648198201, 0, 'hidden'),
(170, 'file', 169, 'yuanpay/import', 'Import', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'dr', 'daoru', 1636171906, 1636171906, 0, 'normal'),
(171, 'file', 169, 'yuanpay/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1636171906, 1636171906, 0, 'normal'),
(172, 'file', 169, 'yuanpay/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1636171906, 1636171906, 0, 'normal'),
(173, 'file', 169, 'yuanpay/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1636171906, 1636171906, 0, 'normal'),
(174, 'file', 169, 'yuanpay/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1636171906, 1636171906, 0, 'normal'),
(175, 'file', 169, 'yuanpay/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1636171906, 1636171906, 0, 'normal'),
(176, 'file', 2, 'yuanlogin', '快捷登录', 'fa fa-qq', '', '', '', 1, 'addtabs', '', 'kjdl', 'kuaijiedenglu', 1636477971, 1642689283, 0, 'normal'),
(177, 'file', 176, 'yuanlogin/import', 'Import', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'dr', 'daoru', 1636477971, 1636477971, 0, 'normal'),
(178, 'file', 176, 'yuanlogin/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1636477971, 1636477971, 0, 'normal'),
(179, 'file', 176, 'yuanlogin/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1636477971, 1636477971, 0, 'normal'),
(180, 'file', 176, 'yuanlogin/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1636477971, 1636477971, 0, 'normal'),
(181, 'file', 176, 'yuanlogin/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1636477971, 1636477971, 0, 'normal'),
(182, 'file', 176, 'yuanlogin/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1636477971, 1636477971, 0, 'normal'),
(183, 'file', 197, 'channel', '通道列表', 'fa fa-google-wallet', '', '', '', 1, 'addtabs', '', 'tdlb', 'tongdaoliebiao', 1636478898, 1636510019, 0, 'normal'),
(184, 'file', 183, 'channel/import', 'Import', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'dr', 'daoru', 1636478898, 1636478898, 0, 'normal'),
(185, 'file', 183, 'channel/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1636478898, 1636478898, 0, 'normal'),
(186, 'file', 183, 'channel/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1636478898, 1636478898, 0, 'normal'),
(187, 'file', 183, 'channel/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1636478898, 1636478898, 0, 'normal'),
(188, 'file', 183, 'channel/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1636478898, 1636478898, 0, 'normal'),
(189, 'file', 183, 'channel/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1636478898, 1636478898, 0, 'normal'),
(197, 'file', 0, 'tongdao', '通道管理', 'fa fa-buysellads', '', '', '', 1, 'addtabs', '', 'tdgl', 'tongdaoguanli', 1636510003, 1636510003, 0, 'normal'),
(198, 'file', 0, 'gonggao', '公告管理', 'fa fa-volume-up', '', '', '', 0, 'addtabs', '', 'gggl', 'gonggaoguanli', 1636510272, 1638016752, 0, 'normal'),
(199, 'file', 0, 'anquan', '安全管理', 'fa fa-cog', '', '', '', 1, 'addtabs', '', 'aqgl', 'anquanguanli', 1636510338, 1636510338, 0, 'normal'),
(200, 'file', 0, 'caiwu', '财务管理', 'fa fa-pie-chart', '', '', '', 1, 'addtabs', '', 'cwgl', 'caiwuguanli', 1636510408, 1636510408, 0, 'normal'),
(243, 'file', 197, 'ewm', '二维码管理', 'fa fa-chain-broken', '', '', '', 1, 'addtabs', '', 'ewmgl', 'erweimaguanli', 1641981774, 1648198233, 0, 'hidden'),
(244, 'file', 243, 'ewm/import', 'Import', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'dr', 'daoru', 1641981774, 1641981774, 0, 'normal'),
(245, 'file', 243, 'ewm/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1641981774, 1641981774, 0, 'normal'),
(246, 'file', 243, 'ewm/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1641981774, 1641981774, 0, 'normal'),
(247, 'file', 243, 'ewm/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1641981774, 1641981774, 0, 'normal'),
(248, 'file', 243, 'ewm/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1641981774, 1641981774, 0, 'normal'),
(249, 'file', 243, 'ewm/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1641981774, 1641981774, 0, 'normal'),
(250, 'file', 197, 'proxy', '代理IP管理', 'fa fa-edge', '', '', '', 1, 'addtabs', '', 'dlIgl', 'dailiIPguanli', 1642694448, 1642694490, 0, 'normal'),
(251, 'file', 250, 'proxy/import', 'Import', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'dr', 'daoru', 1642694448, 1642694448, 0, 'normal'),
(252, 'file', 250, 'proxy/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1642694448, 1642694448, 0, 'normal'),
(253, 'file', 250, 'proxy/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1642694448, 1642694448, 0, 'normal'),
(254, 'file', 250, 'proxy/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1642694448, 1642694448, 0, 'normal'),
(255, 'file', 250, 'proxy/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1642694448, 1642694448, 0, 'normal'),
(256, 'file', 250, 'proxy/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1642694448, 1642694448, 0, 'normal');

-- --------------------------------------------------------

--
-- 表的结构 `fa_category`
--

CREATE TABLE IF NOT EXISTS `fa_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `type` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '栏目类型',
  `name` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `nickname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `flag` set('hot','index','recommend') COLLATE utf8mb4_unicode_ci DEFAULT '',
  `image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '图片',
  `keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '关键字',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '描述',
  `diyname` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '自定义名称',
  `createtime` int(10) DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) DEFAULT NULL COMMENT '更新时间',
  `weigh` int(10) NOT NULL DEFAULT '0' COMMENT '权重',
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `weigh` (`weigh`,`id`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='分类表' AUTO_INCREMENT=14 ;

--
-- 转存表中的数据 `fa_category`
--

INSERT INTO `fa_category` (`id`, `pid`, `type`, `name`, `nickname`, `flag`, `image`, `keywords`, `description`, `diyname`, `createtime`, `updatetime`, `weigh`, `status`) VALUES
(1, 0, 'page', '官方新闻', 'news', 'recommend', '/assets/img/qrcode.png', '', '', 'news', 1491635035, 1491635035, 1, 'normal'),
(2, 0, 'page', '移动应用', 'mobileapp', 'hot', '/assets/img/qrcode.png', '', '', 'mobileapp', 1491635035, 1491635035, 2, 'normal'),
(3, 2, 'page', '微信公众号', 'wechatpublic', 'index', '/assets/img/qrcode.png', '', '', 'wechatpublic', 1491635035, 1491635035, 3, 'normal'),
(4, 2, 'page', 'Android开发', 'android', 'recommend', '/assets/img/qrcode.png', '', '', 'android', 1491635035, 1491635035, 4, 'normal'),
(5, 0, 'page', '软件产品', 'software', 'recommend', '/assets/img/qrcode.png', '', '', 'software', 1491635035, 1491635035, 5, 'normal'),
(6, 5, 'page', '网站建站', 'website', 'recommend', '/assets/img/qrcode.png', '', '', 'website', 1491635035, 1491635035, 6, 'normal'),
(7, 5, 'page', '企业管理软件', 'company', 'index', '/assets/img/qrcode.png', '', '', 'company', 1491635035, 1491635035, 7, 'normal'),
(8, 6, 'page', 'PC端', 'website-pc', 'recommend', '/assets/img/qrcode.png', '', '', 'website-pc', 1491635035, 1491635035, 8, 'normal'),
(9, 6, 'page', '移动端', 'website-mobile', 'recommend', '/assets/img/qrcode.png', '', '', 'website-mobile', 1491635035, 1491635035, 9, 'normal'),
(10, 7, 'page', 'CRM系统 ', 'company-crm', 'recommend', '/assets/img/qrcode.png', '', '', 'company-crm', 1491635035, 1491635035, 10, 'normal'),
(11, 7, 'page', 'SASS平台软件', 'company-sass', 'recommend', '/assets/img/qrcode.png', '', '', 'company-sass', 1491635035, 1491635035, 11, 'normal'),
(12, 0, 'test', '测试1', 'test1', 'recommend', '/assets/img/qrcode.png', '', '', 'test1', 1491635035, 1491635035, 12, 'normal'),
(13, 0, 'test', '测试2', 'test2', 'recommend', '/assets/img/qrcode.png', '', '', 'test2', 1491635035, 1491635035, 13, 'normal');

-- --------------------------------------------------------

--
-- 表的结构 `fa_channel`
--

CREATE TABLE IF NOT EXISTS `fa_channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(50) NOT NULL COMMENT '通道名称',
  `type` varchar(50) NOT NULL COMMENT '通道类型',
  `weigh` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `remark` varchar(50) NOT NULL COMMENT '备注',
  `is_hot` int(11) NOT NULL DEFAULT '0' COMMENT '热门',
  `creat_time` int(11) NOT NULL COMMENT '创建时间',
  `status` int(11) NOT NULL COMMENT '状态',
  `code` varchar(50) NOT NULL COMMENT '通道标识',
  `max_account` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- 转存表中的数据 `fa_channel`
--

INSERT INTO `fa_channel` (`id`, `name`, `type`, `weigh`, `remark`, `is_hot`, `creat_time`, `status`, `code`, `max_account`) VALUES
(1, '支付宝商家版', 'alipay', 2, '本地免挂，备注订单号免输入金额', 0, 1636478903, 1, 'alipay_mg', 1),
(4, '微信店员免挂', 'wxpay', 10, '支持商业版收款，普通版二维码收款', 0, 1636486248, 1, 'wxpay_dy', 1),
(5, '微信收款码', 'wxpay', 6, '云端挂机，免输入金额，备注订单号回调', 0, 1636486267, 1, 'wxpay_cloud', 1),
(8, 'QQ免挂', 'qqpay', 1, 'QQ免挂通道', 0, 1636486345, 1, 'qqpay_mg', 1),
(9, '支付宝个人版', 'alipay', 2, '支付宝个人版免挂', 0, 1636486345, 1, 'alipay_grmg', 1),
(10, '微信赞赏码', 'wxpay', 5, '云端挂机，赞赏码模式根据订单ID回调', 0, 1636486267, 1, 'wxpay_cloudzs', 1),
(11, '微信收款单', 'wxpay', 5, '云端挂机，收款单模式根据订单ID回调', 0, 1636486267, 1, 'wxpay_skd', 1);

-- --------------------------------------------------------

--
-- 表的结构 `fa_command`
--

CREATE TABLE IF NOT EXISTS `fa_command` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '类型',
  `params` varchar(1500) NOT NULL DEFAULT '' COMMENT '参数',
  `command` varchar(1500) NOT NULL DEFAULT '' COMMENT '命令',
  `content` text COMMENT '返回结果',
  `executetime` int(10) unsigned DEFAULT NULL COMMENT '执行时间',
  `createtime` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) unsigned DEFAULT NULL COMMENT '更新时间',
  `status` enum('successed','failured') NOT NULL DEFAULT 'failured' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='在线命令表' AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `fa_command`
--

INSERT INTO `fa_command` (`id`, `type`, `params`, `command`, `content`, `executetime`, `createtime`, `updatetime`, `status`) VALUES
(1, 'crud', '["--table=fa_ewm"]', 'php think crud --table=fa_ewm', 'Build Successed', 1641981758, 1641981758, 1641981758, 'successed'),
(2, 'menu', '["--controller=Ewm"]', 'php think menu --controller=Ewm', 'Build Successed!', 1641981774, 1641981774, 1641981774, 'successed'),
(3, 'crud', '["--delete=1","--table=fa_message_notice"]', 'php think crud --delete=1 --table=fa_message_notice', '/www/wwwroot/code.juhekefu.com/public/../application/admin/controller/MessageNotice.php\n/www/wwwroot/code.juhekefu.com/public/../application/admin/model/MessageNotice.php\n/www/wwwroot/code.juhekefu.com/public/../application/admin/validate/MessageNotice.php\n/www/wwwroot/code.juhekefu.com/application/admin/view/message_notice/add.html\n/www/wwwroot/code.juhekefu.com/application/admin/view/message_notice/edit.html\n/www/wwwroot/code.juhekefu.com/application/admin/view/message_notice/index.html\n/www/wwwroot/code.juhekefu.com/application/admin/view/message_notice/recyclebin.html\n/www/wwwroot/code.juhekefu.com/application/admin/lang/zh-cn/message_notice.php\n/www/wwwroot/code.juhekefu.com/public/assets/js/backend/message_notice.js\nAre you sure you want to delete all those files?  Type ''yes'' to continue: \nOperation is aborted!', 1642681303, 1642681303, 1642681303, 'failured'),
(4, 'crud', '["--delete=1","--table=fa_message_notice"]', 'php think crud --delete=1 --table=fa_message_notice', '/www/wwwroot/code.juhekefu.com/public/../application/admin/controller/MessageNotice.php\n/www/wwwroot/code.juhekefu.com/public/../application/admin/model/MessageNotice.php\n/www/wwwroot/code.juhekefu.com/public/../application/admin/validate/MessageNotice.php\n/www/wwwroot/code.juhekefu.com/application/admin/view/message_notice/add.html\n/www/wwwroot/code.juhekefu.com/application/admin/view/message_notice/edit.html\n/www/wwwroot/code.juhekefu.com/application/admin/view/message_notice/index.html\n/www/wwwroot/code.juhekefu.com/application/admin/view/message_notice/recyclebin.html\n/www/wwwroot/code.juhekefu.com/application/admin/lang/zh-cn/message_notice.php\n/www/wwwroot/code.juhekefu.com/public/assets/js/backend/message_notice.js\nAre you sure you want to delete all those files?  Type ''yes'' to continue: \nOperation is aborted!', 1642681310, 1642681310, 1642681310, 'failured'),
(5, 'crud', '["--table=fa_proxy"]', 'php think crud --table=fa_proxy', 'Build Successed', 1642694436, 1642694436, 1642694436, 'successed'),
(6, 'menu', '["--controller=Proxy"]', 'php think menu --controller=Proxy', 'Build Successed!', 1642694448, 1642694448, 1642694448, 'successed'),
(7, 'crud', '["--delete=1","--table=fa_message_notice"]', 'php think crud --delete=1 --table=fa_message_notice', 'table not found', 1645195983, 1645195983, 1645195983, 'failured'),
(8, 'crud', '["--delete=1","--table=fa_message_notice"]', 'php think crud --delete=1 --table=fa_message_notice', 'table not found', 1645195986, 1645195986, 1645195986, 'failured');

-- --------------------------------------------------------

--
-- 表的结构 `fa_config`
--

CREATE TABLE IF NOT EXISTS `fa_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '变量名',
  `group` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '分组',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '变量标题',
  `tip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '变量描述',
  `type` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '类型:string,text,int,bool,array,datetime,date,file',
  `value` text COLLATE utf8mb4_unicode_ci COMMENT '变量值',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '变量字典数据',
  `rule` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '验证规则',
  `extend` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '扩展属性',
  `setting` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '配置',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统配置' AUTO_INCREMENT=55 ;

--
-- 转存表中的数据 `fa_config`
--

INSERT INTO `fa_config` (`id`, `name`, `group`, `title`, `tip`, `type`, `value`, `content`, `rule`, `extend`, `setting`) VALUES
(1, 'name', 'basic', 'Site name', '请填写站点名称', 'string', '源支付', '', 'required', '', NULL),
(2, 'beian', 'basic', 'Beian', '粤ICP备15000000号-1', 'string', '粤ICP备19137951号-17', '', '', '', NULL),
(3, 'cdnurl', 'basic', 'Cdn url', '如果全站静态资源使用第三方云储存请配置该值', 'string', '', '', '', '', NULL),
(5, 'timezone', 'basic', 'Timezone', '', 'string', 'Asia/Shanghai', '', 'required', '', NULL),
(8, 'fixedpage', 'basic', 'Fixed page', '请尽量输入左侧菜单栏存在的链接', 'string', 'dashboard', '', 'required', '', NULL),
(9, 'categorytype', 'dictionary', 'Category type', '', 'array', '[]', '', '', '', NULL),
(10, 'configgroup', 'dictionary', 'Config group', '', 'array', '{"basic":"基础配置","email":"邮件配置","pay":"支付配置"}', '', '', '', NULL),
(11, 'mail_type', 'email', 'Mail type', '选择邮件发送方式', 'select', '1', '["请选择","SMTP"]', '', '', NULL),
(12, 'mail_smtp_host', 'email', 'Mail smtp host', '错误的配置发送邮件会导致服务器超时', 'string', 'smtp.qq.com', '', '', '', NULL),
(13, 'mail_smtp_port', 'email', 'Mail smtp port', '(不加密默认25,SSL默认465,TLS默认587)', 'string', '465', '', '', '', NULL),
(14, 'mail_smtp_user', 'email', 'Mail smtp user', '（填写完整用户名）', 'string', '', '', '', '', NULL),
(15, 'mail_smtp_pass', 'email', 'Mail smtp password', '（填写您的密码或授权码）', 'string', '', '', '', '', NULL),
(16, 'mail_verify_type', 'email', 'Mail vertify type', '（SMTP验证方式[推荐SSL]）', 'select', '2', '["无","TLS","SSL"]', '', '', NULL),
(17, 'mail_from', 'email', 'Mail from', '', 'string', '', '', '', '', NULL),
(18, 'attachmentcategory', 'dictionary', 'Attachment category', '', 'array', '[]', '', '', '', NULL),
(19, 'title', 'basic', '网站标题', '', 'string', '码支付', '', '', '', '{"table":"","conditions":"","key":"","value":""}'),
(22, 'pay_maxmoney', 'pay', '最大支付金额', '', 'string', '10000', '', '', '', '{"table":"","conditions":"","key":"","value":""}'),
(23, 'pay_minmoney', 'pay', '最小支付金额', '', 'string', '0.01', '', '', '', '{"table":"","conditions":"","key":"","value":""}'),
(24, 'blockname', 'pay', '屏蔽关键字', '', 'text', '百度云|摆渡|云盘|点券|芸盘|萝莉|罗莉|网盘|黑号|q币|Q币|扣币|qq货币|QQ货币|花呗|baidu云|bd云|吃鸡|透视|自瞄|后座|穿墙|脚本|外挂|辅助|检测|武器|套装', '', '', '', '{"table":"","conditions":"","key":"","value":""}'),
(25, 'blockalert', 'pay', '屏蔽提示内容', '', 'string', '温馨提醒该商品禁止出售，如有疑问请联系网站客服！', '', '', '', '{"table":"","conditions":"","key":"","value":""}'),
(30, 'cloud_key', 'pay', '软件通讯密钥', '', 'string', 'YuanPay', '', '', '', '{"table":"","conditions":"","key":"","value":""}'),
(48, 'payUserId', 'pay', '前台充值会员ID', '', 'string', '1000', '', '', '', '{"table":"","conditions":"","key":"","value":""}'),
(49, 'lxqq', 'basic', '联系QQ', '', 'string', '', '', '', '', '{"table":"","conditions":"","key":"","value":""}'),
(50, 'lxqun', 'basic', 'QQ群号', '', 'string', '', '', '', '', '{"table":"","conditions":"","key":"","value":""}'),
(51, 'wxurl', 'basic', '站长微信二维码', '', 'string', '', '', '', '', '{"table":"","conditions":"","key":"","value":""}'),
(52, 'logo', 'basic', '网站LOGO链接', '', 'string', '', '', '', '', '{"table":"","conditions":"","key":"","value":""}'),
(53, 'version', 'basic', '版本号', '', 'string', '500', '', '', '', '{"table":"","conditions":"","key":"","value":""}'),
(54, 'email_off', 'pay', '注册验证类型', '', 'radio', '0', '["普通验证码","邮箱验证码","手机验证码"]', '', '', '{"table":"","conditions":"","key":"","value":""}');

-- --------------------------------------------------------

--
-- 表的结构 `fa_ems`
--

CREATE TABLE IF NOT EXISTS `fa_ems` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `event` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '事件',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '邮箱',
  `code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '验证码',
  `times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '验证次数',
  `ip` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'IP',
  `createtime` int(10) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='邮箱验证码表' AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `fa_ems`
--

INSERT INTO `fa_ems` (`id`, `event`, `email`, `code`, `times`, `ip`, `createtime`) VALUES
(2, 'register', 'kalewang@vip.qq.com', '9945', 0, '39.66.143.149', 1638289778),
(3, 'register', '2269847528@qq.com', '9049', 0, '112.10.22.245', 1638595339),
(4, 'resetpwd', '790818231@qq.com', '3706', 0, '39.66.143.149', 1638612722),
(5, 'resetpwd', '790818231@qq.com', '6274', 0, '39.66.143.149', 1638612740),
(6, 'resetpwd', '790818231@qq.com', '8239', 0, '39.66.143.149', 1638612859),
(7, 'resetpwd', '790818231@qq.com', '6230', 6, '39.66.143.149', 1638613233),
(8, 'resetpwd', '1105602752@qq.com', '5834', 0, '36.148.89.219', 1645881463);

-- --------------------------------------------------------

--
-- 表的结构 `fa_ewm`
--

CREATE TABLE IF NOT EXISTS `fa_ewm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0' COMMENT '商户ID',
  `code` varchar(11) NOT NULL COMMENT '通道标识',
  `qrlist_id` int(11) NOT NULL COMMENT '账号ID',
  `ewm_url` varchar(2500) NOT NULL COMMENT '二维码地址',
  `money` decimal(10,2) NOT NULL COMMENT '金额',
  `creat_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `end_time` int(11) DEFAULT NULL COMMENT '有效时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_news`
--

CREATE TABLE IF NOT EXISTS `fa_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `type` int(11) NOT NULL DEFAULT '1' COMMENT '类型',
  `weigh` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `name` varchar(255) NOT NULL COMMENT '标题',
  `content` text NOT NULL COMMENT '内容',
  `creat_time` int(11) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_order`
--

CREATE TABLE IF NOT EXISTS `fa_order` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `trade_no` varchar(50) DEFAULT NULL COMMENT '本地单号',
  `out_trade_no` varchar(50) DEFAULT NULL COMMENT '商户单号',
  `notify_url` varchar(500) DEFAULT NULL COMMENT '异步通知地址',
  `return_url` varchar(500) DEFAULT NULL COMMENT '同步通知地址',
  `typedata` varchar(50) NOT NULL DEFAULT 'alipay' COMMENT '支付类型:alipay=支付宝,wxpay=微信,qqpay=钱包',
  `user_id` bigint(11) NOT NULL DEFAULT '0' COMMENT '商户ID',
  `name` varchar(255) DEFAULT NULL COMMENT '商品名称',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `truemoney` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '实付金额',
  `qr_id` bigint(11) NOT NULL DEFAULT '0' COMMENT '通道ID',
  `ip` varchar(50) DEFAULT NULL COMMENT '访问IP',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `end_time` int(11) DEFAULT NULL COMMENT '支付时间',
  `out_time` int(11) DEFAULT NULL COMMENT '有效时限',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态:0=未支付,1=已支付',
  `api_memo` text,
  `sitename` varchar(50) DEFAULT NULL,
  `qrcode` text COMMENT '二维码信息',
  `h5_qrurl` varchar(2500) DEFAULT NULL,
  `yuantype` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='订单记录' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_proxy`
--

CREATE TABLE IF NOT EXISTS `fa_proxy` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(50) DEFAULT NULL COMMENT '名称',
  `address` varchar(50) DEFAULT NULL COMMENT 'IP地址',
  `prot` varchar(50) DEFAULT NULL COMMENT '端口',
  `user` varchar(50) DEFAULT NULL COMMENT '用户名',
  `pass` varchar(50) NOT NULL COMMENT '密码',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '状态',
  `creat_time` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_qrlist`
--

CREATE TABLE IF NOT EXISTS `fa_qrlist` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `code` varchar(50) DEFAULT NULL COMMENT '通道标识',
  `user_id` bigint(11) NOT NULL DEFAULT '0' COMMENT '商户ID',
  `type` varchar(50) DEFAULT 'alipay' COMMENT '通道类型:alipay=支付宝,wxpay=微信,qqpay=钱包',
  `qr_url` varchar(5000) DEFAULT NULL COMMENT '二维码地址',
  `wx_name` varchar(50) DEFAULT NULL COMMENT '微信昵称',
  `money` varchar(50) DEFAULT NULL COMMENT '已收款金额',
  `succ_ordercount` int(11) NOT NULL DEFAULT '0' COMMENT '已收款数',
  `cookie` text COMMENT '登录Cookie',
  `createtime` bigint(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` bigint(11) NOT NULL DEFAULT '0' COMMENT '监控时间',
  `end_time` bigint(11) NOT NULL DEFAULT '0' COMMENT '失效时间',
  `zfb_pid` varchar(50) DEFAULT NULL COMMENT '支付宝PID',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态',
  `diaoxian_notity` int(11) NOT NULL DEFAULT '0' COMMENT '掉线通知状态',
  `memo` varchar(50) DEFAULT NULL COMMENT '备注',
  `day_maxmoney` int(11) NOT NULL DEFAULT '0' COMMENT '日收款上限',
  `all_maxmoney` int(11) NOT NULL DEFAULT '0' COMMENT '总收款上限',
  `is_status` int(11) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `is_cloud` int(11) NOT NULL DEFAULT '0' COMMENT '云端守护',
  `cloud_wxid` varchar(50) DEFAULT NULL,
  `cloud_server_code` varchar(50) DEFAULT NULL COMMENT '云端服务器标识',
  `cloud_server_name` varchar(50) DEFAULT NULL COMMENT '云端服务器名称',
  `qq` varchar(50) DEFAULT NULL,
  `num` int(11) DEFAULT '0',
  `land_lx` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='二维码列表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_recharge_order`
--

CREATE TABLE IF NOT EXISTS `fa_recharge_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `orderid` varchar(100) DEFAULT NULL COMMENT '订单ID',
  `user_id` int(10) unsigned DEFAULT '0' COMMENT '会员ID',
  `amount` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '订单金额',
  `payamount` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '支付金额',
  `paytype` varchar(50) DEFAULT NULL COMMENT '支付类型',
  `paytime` int(10) DEFAULT NULL COMMENT '支付时间',
  `ip` varchar(50) DEFAULT NULL COMMENT 'IP地址',
  `useragent` varchar(255) DEFAULT NULL COMMENT 'UserAgent',
  `memo` varchar(255) DEFAULT NULL COMMENT '备注',
  `createtime` int(10) DEFAULT NULL COMMENT '添加时间',
  `updatetime` int(10) DEFAULT NULL COMMENT '更新时间',
  `status` varchar(50) DEFAULT 'created' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='充值表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_risk`
--

CREATE TABLE IF NOT EXISTS `fa_risk` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` bigint(11) NOT NULL DEFAULT '0' COMMENT '商户ID',
  `urltext` varchar(255) NOT NULL DEFAULT '' COMMENT '来源地址',
  `contenttext` varchar(200) NOT NULL DEFAULT '' COMMENT '风控内容',
  `createtime` bigint(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='风控记录' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_sms`
--

CREATE TABLE IF NOT EXISTS `fa_sms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `event` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '事件',
  `mobile` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '手机号',
  `code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '验证码',
  `times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '验证次数',
  `ip` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'IP',
  `createtime` int(10) unsigned DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='短信验证码表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_superads`
--

CREATE TABLE IF NOT EXISTS `fa_superads` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `adsname` varchar(50) NOT NULL DEFAULT '' COMMENT '广告名称',
  `adstag` varchar(50) NOT NULL DEFAULT '' COMMENT '广告标记',
  `adswidth` int(10) NOT NULL DEFAULT '0' COMMENT '广告宽度',
  `adsheight` int(10) NOT NULL DEFAULT '0' COMMENT '广告高度',
  `typedata` enum('1','2','3') NOT NULL DEFAULT '1' COMMENT '类型:1=单图,2=多图,3=代码',
  `createtime` int(10) DEFAULT NULL COMMENT '创建时间',
  `memo` varchar(100) DEFAULT '' COMMENT '备注',
  `status` enum('1','0') NOT NULL DEFAULT '1' COMMENT '状态:1=启用,0=未启用',
  PRIMARY KEY (`id`),
  KEY `adstag` (`adstag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='广告表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_test`
--

CREATE TABLE IF NOT EXISTS `fa_test` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `admin_id` int(10) DEFAULT '0' COMMENT '管理员ID',
  `category_id` int(10) unsigned DEFAULT '0' COMMENT '分类ID(单选)',
  `category_ids` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分类ID(多选)',
  `week` enum('monday','tuesday','wednesday') COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '星期(单选):monday=星期一,tuesday=星期二,wednesday=星期三',
  `flag` set('hot','index','recommend') COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '标志(多选):hot=热门,index=首页,recommend=推荐',
  `genderdata` enum('male','female') COLLATE utf8mb4_unicode_ci DEFAULT 'male' COMMENT '性别(单选):male=男,female=女',
  `hobbydata` set('music','reading','swimming') COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '爱好(多选):music=音乐,reading=读书,swimming=游泳',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '标题',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '图片',
  `images` varchar(1500) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '图片组',
  `attachfile` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '附件',
  `keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '关键字',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '描述',
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '省市',
  `json` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '配置:key=名称,value=值',
  `price` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '价格',
  `views` int(10) unsigned DEFAULT '0' COMMENT '点击',
  `startdate` date DEFAULT NULL COMMENT '开始日期',
  `activitytime` datetime DEFAULT NULL COMMENT '活动时间(datetime)',
  `year` year(4) DEFAULT NULL COMMENT '年',
  `times` time DEFAULT NULL COMMENT '时间',
  `refreshtime` int(10) DEFAULT NULL COMMENT '刷新时间(int)',
  `createtime` int(10) DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) DEFAULT NULL COMMENT '更新时间',
  `deletetime` int(10) DEFAULT NULL COMMENT '删除时间',
  `weigh` int(10) DEFAULT '0' COMMENT '权重',
  `switch` tinyint(1) DEFAULT '0' COMMENT '开关',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci DEFAULT 'normal' COMMENT '状态',
  `state` enum('0','1','2') COLLATE utf8mb4_unicode_ci DEFAULT '1' COMMENT '状态值:0=禁用,1=正常,2=推荐',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='测试表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_user`
--

CREATE TABLE IF NOT EXISTS `fa_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `group_id` int(10) unsigned DEFAULT '0' COMMENT '组别ID',
  `username` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '用户名',
  `nickname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '昵称',
  `password` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '密码',
  `salt` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '密码盐',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '电子邮箱',
  `mobile` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '手机号',
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '头像',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '等级',
  `gender` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `bio` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '格言',
  `money` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '余额',
  `score` int(10) NOT NULL DEFAULT '0' COMMENT '积分',
  `successions` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '连续登录天数',
  `maxsuccessions` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '最大连续登录天数',
  `prevtime` int(10) DEFAULT NULL COMMENT '上次登录时间',
  `logintime` int(10) DEFAULT NULL COMMENT '登录时间',
  `loginip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '登录IP',
  `loginfailure` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '失败次数',
  `joinip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '加入IP',
  `jointime` int(10) DEFAULT NULL COMMENT '加入时间',
  `createtime` int(10) DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) DEFAULT NULL COMMENT '更新时间',
  `token` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'Token',
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '状态',
  `verification` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '验证',
  `user_key` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alipay_time` int(11) NOT NULL,
  `wxpay_time` int(11) NOT NULL,
  `order_out_time` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lixian_notity` int(11) NOT NULL DEFAULT '1',
  `yuyin_notity` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `alipay_feilv` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wxpay_feilv` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `console_notity` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收银台提示信息',
  `pay_temp` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'console' COMMENT '收银台模板',
  `is_login_email` int(11) NOT NULL DEFAULT '0' COMMENT '登录邮件提醒',
  `min_money_tx` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `qqpay_time` int(11) DEFAULT NULL,
  `qqpay_feilv` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_other` int(11) NOT NULL DEFAULT '0' COMMENT '是否开启其他支付方式',
  `daili_id` int(11) NOT NULL DEFAULT '0',
  `v5feilv` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `v5tctime` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_bandqq` int(11) DEFAULT '0',
  `is_bandwx` int(11) DEFAULT '0',
  `qqsid` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wxsid` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `email` (`email`),
  KEY `mobile` (`mobile`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会员表' AUTO_INCREMENT=1000 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_user_group`
--

CREATE TABLE IF NOT EXISTS `fa_user_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '组名',
  `rules` text COLLATE utf8mb4_unicode_ci COMMENT '权限节点',
  `createtime` int(10) DEFAULT NULL COMMENT '添加时间',
  `updatetime` int(10) DEFAULT NULL COMMENT '更新时间',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会员组表' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `fa_user_group`
--

INSERT INTO `fa_user_group` (`id`, `name`, `rules`, `createtime`, `updatetime`, `status`) VALUES
(1, '默认组', '1,3,5,100,101,6,13,15,14,16,17,18,19,8,32,99,37,36,35,34,33,30,31,7,28,29,26,27,24,25,22,23,20,21,2', 1515386468, 1634053907, 'normal');

-- --------------------------------------------------------

--
-- 表的结构 `fa_user_money_log`
--

CREATE TABLE IF NOT EXISTS `fa_user_money_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更余额',
  `before` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更前余额',
  `after` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更后余额',
  `memo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `createtime` int(10) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会员余额变动表' AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `fa_user_money_log`
--

INSERT INTO `fa_user_money_log` (`id`, `user_id`, `money`, `before`, `after`, `memo`, `createtime`) VALUES
(1, 1000, '1000.00', '0.00', '1000.00', '管理员变更金额', 1649064721),
(2, 1000, '88.00', '1000.00', '912.00', '购买商户套餐', 1649064731);

-- --------------------------------------------------------

--
-- 表的结构 `fa_user_rule`
--

CREATE TABLE IF NOT EXISTS `fa_user_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) DEFAULT NULL COMMENT '父ID',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '标题',
  `remark` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `ismenu` tinyint(1) DEFAULT NULL COMMENT '是否菜单',
  `createtime` int(10) DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) DEFAULT NULL COMMENT '更新时间',
  `weigh` int(10) DEFAULT '0' COMMENT '权重',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态',
  `icon` char(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fa fa-circle-o' COMMENT '图标',
  `condition` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '条件',
  `type` enum('menu','file') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'file' COMMENT 'menu为菜单,file为权限节点',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会员规则表' AUTO_INCREMENT=102 ;

--
-- 转存表中的数据 `fa_user_rule`
--

INSERT INTO `fa_user_rule` (`id`, `pid`, `name`, `title`, `remark`, `ismenu`, `createtime`, `updatetime`, `weigh`, `status`, `icon`, `condition`, `type`) VALUES
(1, 0, 'dashboard', 'Dashboard', 'Dashboard tips', 1, 1516168079, 1516168079, 99, 'normal', 'fa fa-dashboard', '', 'file'),
(2, 0, 'api', 'API接口', '', 1, 1516168062, 1634053614, 2, 'normal', '', '', 'file'),
(3, 1, 'dashboard/index', 'View', '', 0, 1515386247, 1634054222, 5, 'normal', 'fa fa-circle-o', '', 'file'),
(4, 2, 'api/user', '会员模块', '', 1, 1515386221, 1537758859, 11, 'hidden', '', '', 'file'),
(5, 0, 'user', 'User center', '', 1, 1515386262, 1516015236, 7, 'normal', 'fa fa-users', '', 'file'),
(6, 5, 'user/secure', '安全管理', '', 1, 1516015012, 1516015012, 10, 'normal', 'fa fa-shield', '', 'file'),
(7, 5, 'user/rich', '财富管理', '', 1, 1541045799, 1541052272, 9, 'normal', 'fa fa-money', '', 'file'),
(8, 5, 'user/general', '常规管理', '', 1, 1541045799, 1541052272, 9, 'normal', 'fa fa-cogs', '', 'file'),
(9, 4, 'api/user/login', '登录', '', 0, 1515386247, 1537758859, 6, 'hidden', '', '', 'file'),
(10, 4, 'api/user/register', '注册', '', 0, 1515386262, 1537758859, 8, 'hidden', '', '', 'file'),
(11, 4, 'api/user/index', '会员中心', '', 0, 1516015012, 1634053609, 10, 'normal', '', '', 'file'),
(12, 4, 'api/user/profile', '个人资料', '', 0, 1516015012, 1634053600, 3, 'normal', '', '', 'file'),
(13, 6, 'user/profile', 'Profile', '', 1, 1516015012, 1516015012, 10, 'normal', 'fa fa-user-o', '', 'file'),
(14, 13, 'user/profile/index', 'View', '', 1, 1516015012, 1634053506, 4, 'normal', 'fa fa-circle-o', '', 'file'),
(15, 13, 'user/profile/edit', 'Edit', '', 1, 1516015012, 1634053507, 4, 'normal', 'fa fa-circle-o', '', 'file'),
(16, 6, 'user/changepwd', 'Change password', '', 1, 1541045799, 1541056067, 8, 'normal', 'fa fa-key', '', 'file'),
(17, 16, 'user/changepwd/index', 'View', '', 0, 1541045799, 1541045799, 0, 'normal', 'fa fa-circle-o', '', 'file'),
(18, 6, 'user/log', '用户日志', '', 1, 1516015012, 1541043105, 7, 'normal', 'fa fa-file-text-o', '', 'file'),
(19, 18, 'user/log/index', 'View', '', 0, 1516015012, 1537758859, 3, 'normal', 'fa fa-circle-o', '', 'file'),
(20, 7, 'user/scorelog', '积分日志', '', 1, 1541045799, 1541050931, 0, 'normal', 'fa fa-file-text-o', '', 'file'),
(21, 20, 'user/scorelog/index', 'View', '', 0, 1541045799, 1541050931, 0, 'normal', 'fa fa-circle-o', '', 'file'),
(22, 7, 'user/recharge', '充值余额', '', 1, 1541045799, 1541050931, 0, 'normal', 'fa fa-cny', '', 'file'),
(23, 22, 'user/recharge/index', 'View', '', 0, 1541045799, 1541045799, 8, 'normal', 'fa fa-circle-o', '', 'file'),
(24, 0, 'user/moneylog', '余额日志', '', 1, 1541045799, 1634054092, 0, 'normal', 'fa fa-file-text-o', '', 'file'),
(25, 24, 'user/moneylog/index', 'View', '', 0, 1516015012, 1541043105, 7, 'normal', 'fa fa-circle-o', '', 'file'),
(26, 7, 'user/withdraw', '余额提现', '', 1, 1541045799, 1541050931, 0, 'normal', 'fa fa-cny', '', 'file'),
(27, 26, 'user/withdraw/index', 'View', '', 0, 1541045799, 1541045799, 8, 'normal', 'fa fa-circle-o', '', 'file'),
(28, 7, 'user/withdrawlog', '提现日志', '', 1, 1541045799, 1541050931, 0, 'normal', 'fa fa-file-text-o', '', 'file'),
(29, 28, 'user/withdrawlog/index', 'View', '', 0, 1516015012, 1541043105, 7, 'normal', 'fa fa-circle-o', '', 'file'),
(30, 8, 'user/invite', '邀请好友', '', 1, 1541045799, 1541050931, 0, 'normal', 'fa fa-users', '', 'file'),
(31, 30, 'user/invite/index', 'View', '', 0, 1516015012, 1541043105, 7, 'normal', 'fa fa-circle-o', '', 'file'),
(32, 8, 'general/attachment', '附件管理', '', 1, 1541045799, 1541050931, 0, 'normal', 'fa fa-file-image-o', '', 'file'),
(33, 32, 'general/attachment/index', 'View', '', 0, 1516015012, 1541043105, 7, 'normal', 'fa fa-circle-o', '', 'file'),
(34, 32, 'general/attachment/add', 'Add', '', 0, 1516015012, 1541043105, 7, 'normal', 'fa fa-circle-o', '', 'file'),
(35, 32, 'general/attachment/edit', 'Edit', '', 0, 1516015012, 1541043105, 7, 'normal', 'fa fa-circle-o', '', 'file'),
(36, 32, 'general/attachment/del', 'Del', '', 0, 1516015012, 1541043105, 7, 'normal', 'fa fa-circle-o', '', 'file'),
(37, 32, 'general/attachment/select', 'Select', '', 0, 1516015012, 1541043105, 7, 'normal', 'fa fa-circle-o', '', 'file'),
(99, 32, 'general/attachment/multi', 'Multi', '', 0, 1516015012, 1541043105, 7, 'normal', 'fa fa-circle-o', '', 'file'),
(100, 5, 'pay', '云端管理', '', 1, 1631170502, 1631170571, 100, 'normal', 'fa fa-circle-o', '', 'file'),
(101, 100, 'qrmanage', '二维码管理', '', 1, 1631170633, 1631170633, 101, 'normal', 'fa fa-circle-o', '', 'file');

-- --------------------------------------------------------

--
-- 表的结构 `fa_user_score_log`
--

CREATE TABLE IF NOT EXISTS `fa_user_score_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `score` int(10) NOT NULL DEFAULT '0' COMMENT '变更积分',
  `before` int(10) NOT NULL DEFAULT '0' COMMENT '变更前积分',
  `after` int(10) NOT NULL DEFAULT '0' COMMENT '变更后积分',
  `memo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '备注',
  `createtime` int(10) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会员积分变动表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_user_token`
--

CREATE TABLE IF NOT EXISTS `fa_user_token` (
  `token` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Token',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `createtime` int(10) DEFAULT NULL COMMENT '创建时间',
  `expiretime` int(10) DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会员Token表';

-- --------------------------------------------------------

--
-- 表的结构 `fa_version`
--

CREATE TABLE IF NOT EXISTS `fa_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `oldversion` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '旧版本号',
  `newversion` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '新版本号',
  `packagesize` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '包大小',
  `content` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '升级内容',
  `downloadurl` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '下载地址',
  `enforce` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '强制更新',
  `createtime` int(10) DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) DEFAULT NULL COMMENT '更新时间',
  `weigh` int(10) NOT NULL DEFAULT '0' COMMENT '权重',
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='版本表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_vippack`
--

CREATE TABLE IF NOT EXISTS `fa_vippack` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `vip_nametext` varchar(200) NOT NULL DEFAULT '' COMMENT '套餐名称',
  `vip_feilvtext` varchar(10) NOT NULL DEFAULT '' COMMENT '套餐费率',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态:0=关闭,1=启用',
  `weigh` bigint(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `money` decimal(10,2) DEFAULT NULL,
  `vip_day` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='会员套餐' AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `fa_vippack`
--

INSERT INTO `fa_vippack` (`id`, `vip_nametext`, `vip_feilvtext`, `status`, `weigh`, `money`, `vip_day`) VALUES
(1, '体验套餐', '0.05', 1, 1, '9.90', 7),
(2, '推荐套餐', '0.03', 1, 2, '88.00', 30),
(3, '年费套餐', '0', 1, 3, '288.00', 365);

-- --------------------------------------------------------

--
-- 表的结构 `fa_withdraw`
--

CREATE TABLE IF NOT EXISTS `fa_withdraw` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0' COMMENT '会员ID',
  `money` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '金额',
  `handingfee` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '手续费',
  `taxes` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '税费',
  `type` varchar(50) DEFAULT '' COMMENT '类型',
  `account` varchar(100) DEFAULT '' COMMENT '提现账户',
  `name` varchar(100) DEFAULT '' COMMENT '真实姓名',
  `memo` varchar(255) DEFAULT NULL COMMENT '备注',
  `orderid` varchar(50) DEFAULT '' COMMENT '订单号',
  `transactionid` varchar(50) DEFAULT '' COMMENT '流水号',
  `status` enum('created','successed','rejected') DEFAULT 'created' COMMENT '状态:created=申请中,successed=成功,rejected=已拒绝',
  `transfertime` int(10) DEFAULT NULL COMMENT '转账时间',
  `createtime` int(10) DEFAULT NULL COMMENT '添加时间',
  `updatetime` int(10) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='提现表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_wxemp`
--

CREATE TABLE IF NOT EXISTS `fa_wxemp` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `wx_name` varchar(50) NOT NULL COMMENT '微信名称',
  `wx_user` varchar(50) NOT NULL COMMENT '微信账号',
  `update_time` int(11) NOT NULL COMMENT '刷新时间',
  `creat_time` int(11) NOT NULL COMMENT '创建时间',
  `status` enum('0','1') NOT NULL DEFAULT '0' COMMENT '状态:0=离线,1=在线',
  `wxid` varchar(50) NOT NULL COMMENT '微信ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `fa_yuanlogin`
--

CREATE TABLE IF NOT EXISTS `fa_yuanlogin` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(50) NOT NULL COMMENT '通道名称',
  `url` varchar(50) NOT NULL COMMENT '通道地址',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` varchar(2500) NOT NULL COMMENT '通道数据',
  `type` int(11) NOT NULL DEFAULT '1' COMMENT '通道类型',
  `weigh` int(11) NOT NULL COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `fa_yuanlogin`
--

INSERT INTO `fa_yuanlogin` (`id`, `name`, `url`, `status`, `value`, `type`, `weigh`) VALUES
(1, '无岸聚合登录', 'http://login.9ym.net/', 1, '{"appid":"","apptoken":"","qq":"1","wx":"1"}', 1, 0),
(2, '聚合登录', '', 0, '{"appid":"\\u8bf7\\u8f93\\u5165APPID","apptoken":"\\u8bf7\\u8f93\\u5165APPKey","qq":"1","wx":"1"}', 2, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
